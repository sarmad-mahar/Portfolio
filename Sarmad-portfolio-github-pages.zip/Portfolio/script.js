const posts = [
  { id: 1, category: 'research', label: 'Research', date: 'Coming soon', title: 'Reading drought through time and place', excerpt: 'A working note on SPI, climate projections, and what arid landscapes can teach us about resilience.', body: 'This is a space for a future field note on drought analysis, climate models, and the careful work of turning a long time series into a useful story.' },
  { id: 2, category: 'fieldwork', label: 'Fieldwork', date: 'Coming soon', title: 'What a forest survey can reveal', excerpt: 'Notes from listening to the people and ecosystems behind carbon sequestration estimates.', body: 'Fieldwork is never just data collection. It is learning to notice the relationships between livelihoods, forests, services, and the decisions that shape all three.' },
  { id: 3, category: 'creative', label: 'Creative', date: 'Coming soon', title: 'The camera as a field instrument', excerpt: 'On photography as a way to slow down, frame change, and make environmental stories felt.', body: 'A photograph can be evidence, invitation, and memory at once. I am interested in the quiet details that help environmental work become more human.' }
];

const root = document.documentElement;
const themeToggle = document.querySelector('[data-theme-toggle]');
const themeIcon = document.querySelector('[data-theme-icon]');
const themeLabel = document.querySelector('[data-theme-label]');
const savedTheme = localStorage.getItem('sarmad-theme');
if (savedTheme) root.dataset.theme = savedTheme;
function updateThemeControl() {
  const isLight = root.dataset.theme === 'light';
  themeIcon.textContent = isLight ? '☀' : '☾';
  themeLabel.textContent = isLight ? 'Light' : 'Dark';
  document.querySelector('meta[name="theme-color"]').setAttribute('content', isLight ? '#eaf1ed' : '#081119');
}
updateThemeControl();
themeToggle.addEventListener('click', () => {
  root.dataset.theme = root.dataset.theme === 'light' ? 'dark' : 'light';
  localStorage.setItem('sarmad-theme', root.dataset.theme);
  updateThemeControl();
});

const sections = [...document.querySelectorAll('[data-section]')];
const navLinks = [...document.querySelectorAll('[data-route]')];
function updateRoute() {
  const current = (location.hash || '#home').slice(1).split('/')[0];
  navLinks.forEach(link => link.classList.toggle('active', link.dataset.route === current));
}
window.addEventListener('hashchange', updateRoute);
updateRoute();

const blogGrid = document.querySelector('[data-blog-grid]');
const emptyState = document.querySelector('[data-blog-empty]');
function renderPosts(filter = 'all') {
  const visible = filter === 'all' ? posts : posts.filter(post => post.category === filter);
  blogGrid.innerHTML = visible.map(post => `
    <article class="blog-card" data-post-id="${post.id}" tabindex="0" role="button" aria-label="Read ${post.title}">
      <span class="card-category">${post.label} / ${post.date}</span><h3>${post.title}</h3><p>${post.excerpt}</p>
      <footer><span>Read note</span><span>↗</span></footer>
    </article>`).join('');
  emptyState.hidden = visible.length > 0;
  blogGrid.querySelectorAll('[data-post-id]').forEach(card => {
    card.addEventListener('click', () => openPost(Number(card.dataset.postId)));
    card.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openPost(Number(card.dataset.postId)); } });
  });
}
renderPosts();
document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('[data-filter]').forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  renderPosts(button.dataset.filter);
}));

const modal = document.querySelector('[data-blog-modal]');
const modalTitle = document.querySelector('[data-modal-title]');
const modalCategory = document.querySelector('[data-modal-category]');
const modalDate = document.querySelector('[data-modal-date]');
const modalBody = document.querySelector('[data-modal-body]');
function openPost(id) {
  const post = posts.find(item => item.id === id);
  if (!post) return;
  modalTitle.textContent = post.title; modalCategory.textContent = `${post.label} / Field note`; modalDate.textContent = post.date; modalBody.textContent = post.body;
  modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false'); document.body.style.overflow = 'hidden';
}
function closePost() { modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true'); document.body.style.overflow = ''; }
document.querySelectorAll('[data-modal-close]').forEach(element => element.addEventListener('click', closePost));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closePost(); });

const observer = new IntersectionObserver(entries => entries.forEach(entry => {
  if (entry.isIntersecting) {
    const id = entry.target.dataset.section;
    navLinks.forEach(link => link.classList.toggle('active', link.dataset.route === id));
  }
}), { rootMargin: '-35% 0px -55% 0px' });
sections.forEach(section => observer.observe(section));
